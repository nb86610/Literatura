# Glosario literario personal

| Término | Significado o uso literario |
|--------|------------------------------|
| "Guiiermo" | Pronunciación irónica de mi nombre, usada por telemarketers. |
| "Amor a los diez" | Referencia al amor infantil, inocente pero profundo. |
| "Sambayón" | Palabra sin cursiva, ya adoptada al español rioplatense. |
| “Llamada desesperada” | Frase recurrente que transmite urgencia irónica. |
