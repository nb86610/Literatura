# Temas recurrentes

- El amor en sus múltiples formas: infancia, patria, amistad, desamor.
- La ironía de lo cotidiano.
- La violencia como subtexto inesperado.
- La doble lectura en los relatos (Piglia Style).
