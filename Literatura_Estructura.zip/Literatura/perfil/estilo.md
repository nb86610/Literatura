# Perfil literario de Guille

## Tono
Narración en voseo rioplatense. Suele mezclar ternura con ironía.  
Evita adjetivos calificativos. Prefiere mostrar acciones antes que describir emociones.

## Influencias
- Albert Camus
- Julio Cortázar
- Ricardo Piglia (estructura de doble historia)
- Humor inteligente al estilo Fontanarrosa

## Objetivo
Escribir relatos breves con un final abierto o sorpresivo, dejando pistas escondidas.

## Estilo preferido
- Primera persona (ocasionalmente segunda)
- Descripciones sensoriales, especialmente de aromas
- Juegos con la ambigüedad y la doble lectura
