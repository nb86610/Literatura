# Reescritura de cuento 1

Texto original y versión reescrita con asistencia de HAL.
