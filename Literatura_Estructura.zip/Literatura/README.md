# Literatura de Guille

Este repositorio contiene mis cuentos, estilo narrativo, glosario y pruebas de escritura realizadas con HAL (ChatGPT).

Está pensado como un laboratorio literario vivo.

## Estructura

- `perfil/` → Documentos sobre mi estilo y preferencias narrativas.
- `cuentos/` → Cuentos terminados o en proceso.
- `pruebas/` → Reescrituras, ejercicios y experimentos literarios.
